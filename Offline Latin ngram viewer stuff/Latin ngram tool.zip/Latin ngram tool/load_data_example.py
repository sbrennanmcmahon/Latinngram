import sqlite3
import os
import re
from cltk.stem.latin.j_v import JVReplacer
from cltk.tokenize.word import WordTokenizer
from cltk.stem.lemma import LemmaReplacer
from cltk.corpus.utils.importer import CorpusImporter

# visualiser imports.
import tkinter
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import Rectangle
import numpy as np

def get_lemma_usage_dates(lemma, cursor):
    query = f"select lemma_counts.work_title, lemma_counts.count, perseus_authors.start_date, perseus_authors.end_date, perseus_authors.author from lemma_counts inner join perseus_authors on lemma_counts.work_title=perseus_authors.text_filename AND lemma_counts.lemma='{lemma}';"
    cursor.execute(query)
    return cursor.fetchall()


# create a connection to the database
conn = sqlite3.connect(r'G:/My Drive/2023/CESTA Work/Latin ngram tool/sqlite/db/pythonsqlite.db')

# create a cursor object
c = conn.cursor()

raw = get_lemma_usage_dates('ut', c)
# data is formatted as: earliest date, latest date, number of lemmas in that range, author.
data = []
total_lemmas = 0
for row in raw:
    new_entry = (int(row[2]), int(row[3]), row[1], row[4])
    print(new_entry)
    data.append(new_entry)
    total_lemmas += new_entry[2]

def get_duration(element):
    return -(element[1] - element[0])

# now sort it for curve generation.
data.sort(key=get_duration)

# Now, visualize.
fig, ax = plt.subplots()

# This needs to be here to make mpl function properly.
ax.plot([0,0],[0,0],color="cyan")

min_year = min( [x[0] for x in data] ) - 10
max_year = max( [x[1] for x in data] ) + 10

plt.xlim(min_year, max_year)
plt.ylim(0, total_lemmas)

ypos = 0
for item in data:
    # make lines thicker if they have more occurances.
    weight = item[2]
    ax.add_patch( Rectangle((item[0], ypos), item[1]-item[0], weight, color="blue", alpha=0.2 ) )
    ypos += weight

plt.xlabel("Year")
plt.ylabel("Terms")
plt.title("Whoa, a chart!")
plt.show()