import csv
import sqlite3

def import_data_from_csv(csv_file_path, table_name):
    # Connect to the SQLite database
    conn = sqlite3.connect('G:/My Drive/2023/CESTA Work/Latin ngram tool/sqlite/db/pythonsqlite.db')
    cursor = conn.cursor()

    cursor.execute(f"DROP TABLE IF EXISTS {table_name}")

    # Create the table in SQLite
    create_table_query = '''
        CREATE TABLE "{}" (
            pers_filename TEXT,
            text_filename TEXT,
            start_date TEXT,
            end_date TEXT,
            author TEXT,
            title TEXT
        );
    '''.format(table_name)
    cursor.execute(create_table_query)

    # Read the data from the CSV file
    with open(csv_file_path, 'r') as csv_file:
        csv_reader = csv.reader(csv_file)
        next(csv_reader)  # Skip the header row if present

        # Insert the data into the SQLite table
        insert_query = 'INSERT INTO "{}" (pers_filename, text_filename, start_date, end_date, author, title) VALUES (?, ?, ?, ?, ?, ?)'
        for row in csv_reader:
            row2 = row
            row2[1] = row2[1] + '.txt'
            cursor.execute(insert_query.format(table_name), row)

    # Commit the changes and close the database connection
    conn.commit()
    conn.close()

    print('Data import successful.')

def main():
    csv_file_path = 'G:/My Drive/2023/CESTA Work/Latin ngram tool/Perseus_auth_db_complete.csv'
    table_name = 'perseus_authors'

    import_data_from_csv(csv_file_path, table_name)

if __name__ == '__main__':
    main()
