"""
File: lemmatiser.py
-------------------
# This script takes a clean Latin text file, lemmatises it, and saves a lemmatised version as a new file with just the lemmatised text. 
# It is slightly tweaked from a CLTK tutorial written by Annie Lamar and adapted to work with my dataset. It uses an earlier version of CLTK (3.7?)
# The process is: 
#   1. Opens up the clean file and reads it.
#   2. Goes through each line of the file.
#   3. Replaces the j's and v's in each line.
#   4. Tokenizes each line of Latin.
#   5. Lemmatizes each line.
#   6. Adds the lemmatized tokens to all_lemmata.
"""

# importing all the important bits from the older version of cltk.
import os
import re
from cltk.stem.latin.j_v import JVReplacer
from cltk.tokenize.word import WordTokenizer
from cltk.stem.lemma import LemmaReplacer
from cltk.corpus.utils.importer import CorpusImporter

# setting locations 
PLAINTEXT_LATIN_FOLDER = 'G:/My Drive/2023/CESTA Work/Latin ngram tool/xml-stripped-data/'
OUTPUT_FOLDER = 'G:/My Drive/2023/CESTA Work/Latin ngram tool/lemmatized-data/'

# defining the corpus importer and setting up variables
corpus_importer = CorpusImporter('latin')
corpus_importer.import_corpus('latin_models_cltk')
jv_replacer = JVReplacer()
word_tokenizer = WordTokenizer('latin')
lemmatizer = LemmaReplacer('latin')

def get_lemmata_counts(latin):
    lemmata_counts = {}
    for line in latin:
        # 3. Replaces the j's and v's in each line
        jv_line = jv_replacer.replace(line.lower())
        # 4. Tokenizes each line of Latin
        latin_tokens = word_tokenizer.tokenize(jv_line.lower())
        latin_tokens = [jv_replacer.replace(token) for token in latin_tokens if len(token) > 0]   
        # 5. Lemmatizes each line
        latin_lemmata = lemmatizer.lemmatize(latin_tokens)
        # removes random punctuation that was getting caught in the lemmatiser. Keeps the number following the lemma assigned by lemmatiser.
        for lemma in latin_lemmata:
            if len(re.sub(r'[^\w\s]', '', lemma)) > 0:
                if lemma in lemmata_counts:
                    lemmata_counts[lemma] = lemmata_counts[lemma] + 1
                else:
                    lemmata_counts[lemma] = 1
    return lemmata_counts

total = 0
error = 0
lemmata_counts_by_work = {}
for filename in os.listdir(PLAINTEXT_LATIN_FOLDER):
    if filename.endswith('.txt'):
        total += 1
        #try:
        with open(os.path.join(PLAINTEXT_LATIN_FOLDER, filename), encoding="utf-8") as latin_file:
            lemmata_counts = get_lemmata_counts(latin_file.readlines())
            work_title = filename
            lemmata_counts_by_work[work_title] = lemmata_counts
        break

print(lemmata_counts_by_work)
        # except Exception as e:
        #     #didn't work for some reason
        #     #skip over this one and print out what went wrong
        #     print("something went wrong with file " + filename)
        #     print(e)
        #     error += 1
