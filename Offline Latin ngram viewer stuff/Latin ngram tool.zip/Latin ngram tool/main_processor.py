"""
File: lemma_matrix.py
-------------------
Main script for the ngram program to process the lemmatised words and create the data for the ngram viewer.
  1. for every lemmatised file, saves information on how many times each lemma shows up inside it.
  2. creates a matrix and saves the info about the distribution of each lemma there.

"""
import os

folder = 'G:/My Drive/2023/CESTA Work/Latin ngram tool/lemmatized-data'


# loop through all files in the xml-stripped-data
for filename in os.listdir(folder):
    if filename.endswith('.txt'):
        # call the other Python script and pass it the file path
        os.system('lemmatiser.py ' + os.path.join(folder, filename))


# This provided line is required at the end of a Python file
# to call the main() function.
# if __name__ == '__main__':
#     main()