import sqlite3
import os
import re
from cltk.stem.latin.j_v import JVReplacer
from cltk.tokenize.word import WordTokenizer
from cltk.stem.lemma import LemmaReplacer
from cltk.corpus.utils.importer import CorpusImporter

# setting locations
PLAINTEXT_LATIN_FOLDER = 'G:/My Drive/2023/CESTA Work/Latin ngram tool/xml-stripped-data/'
OUTPUT_FOLDER = 'G:/My Drive/2023/CESTA Work/Latin ngram tool/sqlite/db/'

# create a connection to the database
conn = sqlite3.connect(r'G:/My Drive/2023/CESTA Work/Latin ngram tool/sqlite/db/pythonsqlite.db')

# create a cursor object
c = conn.cursor()

# defining the corpus importer and setting up variables
corpus_importer = CorpusImporter('latin')
corpus_importer.import_corpus('latin_models_cltk')
jv_replacer = JVReplacer()
word_tokenizer = WordTokenizer('latin')
lemmatizer = LemmaReplacer('latin')

def get_lemmata_counts(latin):
    lemmata_counts = {}
    for line in latin:
        # 3. Replaces the j's and v's in each line
        jv_line = jv_replacer.replace(line.lower())
        # 4. Tokenizes each line of Latin
        latin_tokens = word_tokenizer.tokenize(jv_line.lower())
        latin_tokens = [jv_replacer.replace(token) for token in latin_tokens if len(token) > 0]   
        # 5. Lemmatizes each line
        latin_lemmata = lemmatizer.lemmatize(latin_tokens)
        # removes random punctuation that was getting caught in the lemmatiser. Keeps the number following the lemma assigned by lemmatiser.
        for lemma in latin_lemmata:
            if len(re.sub(r'[^\w\s]', '', lemma)) > 0:
                if lemma in lemmata_counts:
                    lemmata_counts[lemma] = lemmata_counts[lemma] + 1
                else:
                    lemmata_counts[lemma] = 1
    return lemmata_counts

def get_num_entries_for_work(work_title, c):
    query = f"select count(*) from lemma_counts where work_title=\"{work_title}\";"
    c.execute(query)
    result = int(c.fetchone()[0])
    return result

def remove_all_entries_for_work(work_title, c):
    c.execute("DELETE FROM lemma_counts WHERE work_title=\"{work_title}\";")

def save_plaintext_to_database(filename, conn, c):
    lemmata_counts = {}
    work_title = filename
    with open(os.path.join(PLAINTEXT_LATIN_FOLDER, filename), encoding="utf-8") as latin_file:
        print(f"Processing file: {filename}")
        lemmata_counts = get_lemmata_counts(latin_file.readlines())

    # create a table for the lemma counts
    c.execute('''CREATE TABLE IF NOT EXISTS lemma_counts
                (
                    lemma TEXT,
                    work_title TEXT, 
                    count INT,
                    CONSTRAINT Unique_LemmaWork UNIQUE(lemma, work_title)
                );''')

    # loop through the dictionary and insert the data into the table
    full_number = len(lemmata_counts)
    previous_number = get_num_entries_for_work(work_title, c)
    print(f"Starting {work_title}. We have {full_number} vs {previous_number} in the database.")    
    if full_number != previous_number:
        remove_all_entries_for_work(work_title, c)
        conn.commit()
        batchInsertData = []
        for lemma, count in lemmata_counts.items():
            batchInsertData.append((lemma, work_title, count))
        c.executemany("INSERT INTO lemma_counts VALUES (?, ?, ?);", batchInsertData)
        conn.commit()
        print(f"Finished {work_title}")
    else:
        print("This work does not seem to have changed, skipping.")

# commit the changes to the database

# define a function to query the database
def query_database(lemma):
    #c.execute("SELECT work_title, count FROM lemma_counts WHERE lemma=?", (lemma))
    c.execute("SELECT * FROM lemma_counts;")
    result = c.fetchall()
    return result

all_plain_latin = [x for x in os.listdir(PLAINTEXT_LATIN_FOLDER) if x.endswith('.txt')]
done = 0
total = len(all_plain_latin)
for filename in all_plain_latin:
    save_plaintext_to_database(filename, conn, c)
    done += 1
    print(f"{100.0*(done / total)}% done")
