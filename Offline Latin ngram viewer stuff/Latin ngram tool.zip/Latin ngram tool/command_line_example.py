import sqlite3
import sys

def load_lemma_counts_from_db(lemma):
    with sqlite3.connect("sqlite\\db\\pythonsqlite.db") as conn:
        cursor = conn.cursor()
        query = f"select * from lemma_counts where count=\"{lemma}\";"
        print(query)
        results = cursor.execute(query)
        return results.fetchall()

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Invalid command line arguments. Please specify a lemma to query.")
    else:
        target_lemma = sys.argv[1]
        print(load_lemma_counts_from_db(target_lemma))