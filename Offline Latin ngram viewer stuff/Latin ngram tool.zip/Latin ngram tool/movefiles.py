import os
import shutil

data_folder = r'C:\Users\sbren\My Drive\2023\CESTA Work\Latin ngram tool\data'
data4_folder = r'C:\Users\sbren\My Drive\2023\CESTA Work\Latin ngram tool\data4'
data5_folder = r'C:\Users\sbren\My Drive\2023\CESTA Work\Latin ngram tool\data5'

data_files = set(os.listdir(data_folder))
data4_files = set(os.listdir(data4_folder))

for file in data4_files - data_files:
    source_file = os.path.join(data4_folder, file)
    dest_file = os.path.join(data5_folder, file)
    shutil.move(source_file, dest_file)
