"""
File: xmltagstripper.py
-------------------
Strips XML tags from a Perseus file, the, saves new version in xml-stripped-data folder.

"""

import xml.etree.ElementTree as ET
import unidecode
import re
import os

PERSEUS_XML_FOLDER = 'G:/My Drive/2023/CESTA Work/Latin ngram tool/data/'
OUTPUT_FOLDER = 'G:/My Drive/2023/CESTA Work/Latin ngram tool/xml-stripped-data/'

def ProcessText(text):
    processed_text = re.sub(r'This pointer pattern extracts Book and Chapter', '', processed_text)
    processed_text = re.sub(r'This pointer pattern extracts book and poem', '', processed_text)
    processed_text = re.sub(r'This pointer pattern extracts poem and line', '', processed_text)
    processed_text = re.sub(r'This pointer pattern extracts Chapter', '', processed_text)
    processed_text = re.sub(r'This pointer pattern extracts Book', '', processed_text)
    processed_text = re.sub(r'This pointer pattern extracts line', '', processed_text)
    processed_text = re.sub(r'\s+', ' ', text).strip() + '\n'
    processed_text = re.sub(r'[^A-Za-z ]', '', processed_text)
    processed_text = unidecode.unidecode(processed_text)
    #need to also add in a line here to remove all punctuation since it seems to still showing up in the lemmatiser
    return processed_text

def SanitizeFileName(text):
    return re.sub(r'\s+', ' ', text).strip()

def strip_xml(filename):
    with open(filename, encoding="utf-8") as inputFile:
        tree = ET.parse( inputFile )
        root = tree.getroot()
        lines = []
        title = 'Untitled'
        author = 'Anon'
        for element in root.iter():
            if ( element.tag.endswith('}l') or element.tag.endswith('}p') ) and element.text:
                elementText = ''.join(element.itertext())
                lines.append(ProcessText(elementText))
 
            elif element.tag.endswith("titleStmt"):
                # Now we can extract the title element from this.
                for child in element:
                    if child.tag.endswith("title"):
                        title = SanitizeFileName(''.join(child.itertext()))
                    elif child.tag.endswith("author"):
                        author = SanitizeFileName(''.join(child.itertext()))

        if(author == None or str(author) == ""):
            print("Invalid author / data for file: " + filename)
            return
        if(title == None or str(title) == ""):
            print("Invalid title / data for file: " + filename)
            return

        #name the new file by the author and title 
        new_file_name = os.path.join(str(OUTPUT_FOLDER),str(author)+' '+str(title)+'.txt')
        text = ''.join(lines)
        
        # save processed file
        if os.path.exists(new_file_name):
            print('error with '+str(new_file_name))
        else:
            with open(new_file_name, "w", encoding="utf-8") as f:
                f.write(text)

total = 0
error = 0
for filename in os.listdir(PERSEUS_XML_FOLDER):
    if filename.endswith('.xml'):
        total += 1
        try:
            strip_xml(os.path.join(PERSEUS_XML_FOLDER, filename))
        except Exception as e:
            #didn't work for some reason
            #skip over this one and print out what went wrong
            print("something went wrong with file " + filename)
            print(e)
            error += 1

print("Finished, error rate was: " + str(100.0*(error/total)) + "% with " + str(error) + " error files.")
