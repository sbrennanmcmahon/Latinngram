"""
File: htmltagstripper.py
-------------------
Strips XML tags from a Perseus file, the, saves new version in xml-stripped-data folder.

"""

import re
import os
import requests
from bs4 import BeautifulSoup
import pandas as pd

html_content = ""
with open("TLLauthdb.html", encoding="utf-8") as f:
    html_content = f.read()

# Parse the HTML content using BeautifulSoup
soup = BeautifulSoup(html_content, 'html.parser')

table = soup.find('table')
if table == None:
    print("Error: couldn't find any tables in the html.")
    
# rows = table.find_all('tr')
# for row in rows:
#     cells = row.find_all('td')
#     for cell in cells:
#         print(cell.text)

aetas_index = 1
notae_index = 2
rows = table.find_all('tr')

def sanitize(text):
    return text.strip()

def is_name(cell):
    return cell.u != None

def get_name(cell):
    all_us = cell.find_all('u')
    result = ''.join(u.text for u in all_us)
    return result

# Loop over the rows again to extract the data
data = []
last_author_data = None

DATA_AUTHOR_NAME = 1
DATA_WORKS = 2

for i, row in enumerate(rows):
    cells = row.find_all('td')
    # data struct: (id_number, author_name, all_rows)
    if len(cells) > notae_index:
        aetas = sanitize(cells[aetas_index].text)
        notae = sanitize(cells[notae_index].text)

        if is_name(cells[notae_index]):
            last_author_data = (i, get_name(cells[notae_index]), [])
            data.append(last_author_data)

        last_author_data[DATA_WORKS].append((aetas, notae))

for i in range(0,25):
    print(data[i])

#df = pd.DataFrame(data, columns=['aetas', 'notae'])
#print(df.head())

