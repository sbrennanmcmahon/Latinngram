"""
file: idperseusfiles.py
This file makes a list of tuples of the names in the Perseus XML files, and their actual author/title combos.
It checks if there's a file being overwritten by the xmltagstripper.py due to file name duplication.
"""

import xml.etree.ElementTree as ET
import unidecode
import re
import os

PERSEUS_XML_FOLDER = 'G:/My Drive/2023/CESTA Work/Latin ngram tool/data/'

list_of_auth_titles = []

def SanitizeFileName(text):
    return re.sub(r'\s+', ' ', text).strip()

def get_filename(filename):
    with open(filename, encoding="utf-8") as inputFile:
        tree = ET.parse( inputFile )
        root = tree.getroot()
        title = 'Untitled'
        author = 'Anon'
        for element in root.iter():
            if ( element.tag.endswith('}l') or element.tag.endswith('}p') ) and element.text:
                elementText = ''.join(element.itertext())
 
            elif element.tag.endswith("titleStmt"):
                # Now we can extract the title element from this.
                for child in element:
                    if child.tag.endswith("title"):
                        title = SanitizeFileName(''.join(child.itertext()))
                    elif child.tag.endswith("author"):
                        author = SanitizeFileName(''.join(child.itertext()))

        if(author == None or str(author) == ""):
            print("Invalid author / data for file: " + filename)
            return
        if(title == None or str(title) == ""):
            print("Invalid title / data for file: " + filename)
            return

        #name the new file by the author and title 
        new_file_name = str(author)+' '+str(title)
        return (filename,new_file_name)

total = 0
error = 0
for filename in os.listdir(PERSEUS_XML_FOLDER):
    if filename.endswith('.xml'):
        total += 1
        try:
            new_name = get_filename(os.path.join(PERSEUS_XML_FOLDER, filename))
            list_of_auth_titles.append(new_name)
        except Exception as e:
            #didn't work for some reason
            #skip over this one and print out what went wrong
            print("something went wrong with file " + filename)
            print(e)
            error += 1

with open('names_of_files.txt', "w") as f:
    for namepair in list_of_auth_titles:
        f.write(str(namepair))
        f.write('\n')
    
print("Finished, error rate was: " + str(100.0*(error/total)) + "% with " + str(error) + " error files.")
