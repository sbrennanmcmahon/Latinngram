import tkinter
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import Rectangle
import numpy as np

fig, ax = plt.subplots()

# This needs to be here to make mpl function properly.
ax.plot([0,0],[0,0],color="cyan")
#ax.add_patch( Rectangle((2, 2), 3, 3, color="yellow", alpha=0.3))

# This is placeholder data, eventually it'll be replaced.
data = [
    (-212,-205, "PLAVT. Asin. 5, 2, 24"),
    (-190,-184, "PLAVT. Persa 192"),
    (-160,-120, "PERS. 4, 39 "),
    (-79,-55, "LVCR. 4, 1273"),
    (-79,-55, "LVCR. 4, 1107"),
    (-79,-55, "LVCR. 4, 1100"),
    (-79,-55, "LVCR. 4, 1272"),
    (-38,-32, "VERG. Georg. 3, 136"),
    (-38,-32, "VERG. Georg. 3, 136"),
    (-30,-30, "HOR. sat. 2, 3, 247"),
    (-24,-9, "Liv.23.47.6"),
    (40,70, "Colum. De cult. hort. 157."),
    (85,90, "MART. 7, 102"),
    (85,90, "MART. 3, 72"),
    (85,90, "MART. 4, 86, 11"),
    (90,95, "MART. 9, 21"),
    (413,426, "AVG. civ. 7, 21 p. 299, 19 (Sancta Aurelius Augustus Episcopus. De Civitate)"),
    (1258,1271, "Matthew of Vendome, Milo.184")
]

min_year = min( [x[0] for x in data] ) - 10
max_year = max( [x[1] for x in data] ) + 10

ypos_lookup = {}
ypos = 0
for item in data:
    if item[2] not in ypos_lookup:
        ypos_lookup[item[2]] = ypos
        ypos += 1

has_draw_label = {}

plt.xlim(min_year, max_year)
plt.ylim(0, len(ypos_lookup))

for item in data:
    ypos = ypos_lookup[item[2]]
    ax.add_patch( Rectangle((item[0], ypos + 0.1), item[1]-item[0], 0.8, color="blue", alpha=0.2 ) )
    if item[2] not in has_draw_label:
        plt.text(item[0] + item[1] * 0.5, ypos + 0.5, item[2] )
        has_draw_label[item[2]] = True
    ypos += 1

plt.xlabel("Year")
plt.ylabel("Terms")
plt.title("Whoa, a chart!")
plt.show()
